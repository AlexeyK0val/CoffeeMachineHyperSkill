package machine;
import java.util.Scanner;


public class CoffeeMachine {

    static Scanner scan = new Scanner(System.in);
    static boolean exit = false;

    public static void main(String[] args) {
        Machine c = new Machine(400, 540, 120, 9, 550);
        while (!exit){
        chooseAction(c);}
    }

    public static void chooseAction(Machine machine){

        System.out.println("Write action (buy, fill, take,remaining, exit):");

        String action = scan.nextLine();
        switch (action){
            case "buy":
                machine.buy();
                break;

            case "fill":
                machine.fill();
                break;

            case "take":
                machine.take();
                break;
            case "exit":
                exit = machine.shutDown();
                break;
            case "remaining":
                machine.printMachine();
                break;

            default:
                System.out.println("Please enter a correct input");
                break;
        }
    }
}
