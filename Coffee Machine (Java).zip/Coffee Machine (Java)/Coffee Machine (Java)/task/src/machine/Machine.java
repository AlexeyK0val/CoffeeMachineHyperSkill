package machine;

import java.util.Scanner;

enum State{
    READY,
    SHUTDOWN,
    COFFEE_MENU,

}
public class Machine {
    private State state = State.READY;
    private int[] espresso = {250,16}; // ingredients list {ml of water, g of coffee beans}
    private int[] latte = {350,75,20}; // ingredients list {ml of water, ml of milk, g of coffee beans}
    private int[] cappuccino = {200, 100, 12}; // ingredients list {ml of water, ml of milk, g of coffee beans}



    private static Scanner scan = new Scanner(System.in); // class scanner


    private int waterAmount; // manipulate variable in the instance
    private int milkAmount;  // manipulate variable in the instance
    private int beanAmount; // manipulate variable in the instance
    private int coffeeCups; // manipulate variable in the instance
    private int money; // manipulate variable in the instance





    //Machine constructor - declares the amount of each ingredient at the beginning of the program

    public Machine(int waterAmount, int milkAmount, int beanAmount, int coffeeCups, int money) {
        this.waterAmount = waterAmount;
        this.milkAmount = milkAmount;
        this.beanAmount = beanAmount;
        this.coffeeCups = coffeeCups;
        this.money = money;
    }





    //prints each ingredient in the machine in the desired format
    public void printMachine() {
        System.out.println("The coffee machine has:\n" + waterAmount + " ml of water\n" + milkAmount + " ml of milk\n" +
                beanAmount + "g of coffee beans\n" +
                coffeeCups + " disposable cups\n$" + money + " of money\n\n");
    }



    //Shutdown Machine

    public boolean shutDown(){
        state = State.SHUTDOWN;
        boolean b = true;
        return b;
    }


    //the user can buy three types of coffee from the machine. The method also validates whether the user has enough ingredients
    public void buy() {
        state = State.COFFEE_MENU;
        if (coffeeCups > 0){
            coffeeCups = coffeeCups - 1;
        }
        else{
            System.out.println("You do not have enough cups");
        }
        System.out.println("What do you want to buy? 1 - expresso, 2 - latte, 3 - cappucino, back - to main menu:");

        String coffee = scan.nextLine();
        switch (coffee) {
            case "1":
                if (waterAmount < espresso[0]){
                    System.out.println("You don't have enough water!");
                }
                else if (beanAmount < espresso[1]){
                    System.out.println("You don't have enough coffee beans!");
                }
                else if (money < espresso[2]){
                    System.out.println("You don't have enough money");
                }
                else{
                waterAmount = waterAmount - 250;
                beanAmount = beanAmount - 16;
                money = money + 4;}
                break;
            case "2":
                if (waterAmount < latte[0]){
                    System.out.println("You don't have enough water!");
                }
                else if (milkAmount < latte[1]){
                    System.out.println("You don't have enough milk!");
                }
                else if (beanAmount < latte[2]){
                    System.out.println("You don't have enough coffee beans!");
                }
                else{
                milkAmount = milkAmount - 75;
                beanAmount = beanAmount - 20;
                waterAmount = waterAmount - 350;
                money = money + 7;}
                break;
            case "3":
                if (waterAmount < cappuccino[0]){
                    System.out.println("You don't have enough water!");
                }
                if (milkAmount < cappuccino[1]){
                    System.out.println("You don't have enough milk!");
                }
                else if (beanAmount < cappuccino[2]){
                    System.out.println("You don't have enough coffee beans!");
                }
                else{
                milkAmount = milkAmount - 100;
                beanAmount = beanAmount - 12;
                waterAmount = waterAmount - 200;
                money = money + 6;}
                break;
            case "back":{
                System.out.print("Incorrect Input");
                break;
            }
            default:
                break;
        }
        state = State.READY;

    }



    // this method allows the User to take money from the machine, leaving it at $0
    public void take() {
        System.out.println("I gave you $" + money + "\n\n");
        money = 0;
    }




    // this method allows the user to fill the machine, for whatever reason they may need
    public void fill() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Write how many ml of water you want to add:");
        int addedWater = scan.nextInt();
        System.out.println("Write how many ml of milk you want to add:");
        int addedMilk = scan.nextInt();
        System.out.println("Write how many grams of coffee beans you want to add:");
        int addedBeans = scan.nextInt();
        System.out.println("Write how many disposable cups you want to add:");
        int addedCups = scan.nextInt();
        coffeeCups += addedCups;
        waterAmount += addedWater;
        milkAmount += addedMilk;
        beanAmount += addedBeans;

    }


}

